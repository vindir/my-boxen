require 'spec_helper'

describe 'hangout_plugin' do
  it do
    should contain_package('hangout_plugin').with({
      :privider => 'appdmg',
      :source   => 'https://dl.google.com/googletalk/googletalkplugin/GoogleVoiceAndVideoSetup.dmg',
    })
  end
end