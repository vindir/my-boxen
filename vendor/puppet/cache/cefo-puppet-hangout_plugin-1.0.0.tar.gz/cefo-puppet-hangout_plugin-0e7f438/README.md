# Google Hangout Plugin Puppet Module for Boxen


## Usage

```puppet
include hangout_plugin
```

## Required Puppet Modules

* boxen
